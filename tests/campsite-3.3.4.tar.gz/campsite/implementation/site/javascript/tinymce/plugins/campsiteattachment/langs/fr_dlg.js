tinyMCE.addI18n('fr.campsiteattachment_dlg',{
title:"Insert link to article file"
});
