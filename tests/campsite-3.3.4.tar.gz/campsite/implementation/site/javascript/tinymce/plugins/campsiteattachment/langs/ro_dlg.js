tinyMCE.addI18n('ro.campsiteattachment_dlg',{
title:"Insert link to article file"
});
