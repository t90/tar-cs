tinyMCE.addI18n('pt.campsiteattachment_dlg',{
title:"Insert link to article file"
});
