tinyMCE.addI18n('es.paste_dlg',{
text_title:"Use CTRL+V en su teclado para pegar el texto en la ventana.",
text_linebreaks:"Keep linebreaks",
word_title:"Use CTRL+V en su teclado para pegar el texto en la ventana."
});