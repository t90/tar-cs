tinyMCE.addI18n('en.campsiteattachment',{
title:"Insert link to article file",
select_to_link:"You need to select some text before creating a link to a file"
});
