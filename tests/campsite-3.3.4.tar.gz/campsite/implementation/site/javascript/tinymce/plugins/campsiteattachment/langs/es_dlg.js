tinyMCE.addI18n('es.campsiteattachment_dlg',{
title:"Insertar enlace a archivo adjunto del art&iacute;culo"
});
