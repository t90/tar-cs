tinyMCE.addI18n('ru.campsiteattachment_dlg',{
title:"Insert link to article file"
});
