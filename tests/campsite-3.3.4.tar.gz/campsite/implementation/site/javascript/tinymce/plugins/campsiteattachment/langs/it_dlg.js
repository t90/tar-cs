tinyMCE.addI18n('it.campsiteattachment_dlg',{
title:"Insert link to article file"
});
