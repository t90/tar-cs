tinyMCE.addI18n('cs.campsiteattachment_dlg',{
title:"Insert link to article file"
});
