tinyMCE.addI18n('en.campsiteattachment_dlg',{
desc:"Campsite Attachment",
title:"Insert link to article file",
select:"Select",
cancel:"Cancel"
});
